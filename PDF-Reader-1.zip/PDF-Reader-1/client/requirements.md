## Packages
recharts | For dashboard analytics and data visualization
date-fns | For date formatting in tables and charts

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
