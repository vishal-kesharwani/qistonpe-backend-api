import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// Helper type to match the complex input schema
type InsertPurchaseOrder = z.infer<typeof api.purchaseOrders.create.input>;

export function usePurchaseOrders(filters?: { vendorId?: number; status?: string }) {
  return useQuery({
    queryKey: [api.purchaseOrders.list.path, filters],
    queryFn: async () => {
      const url = new URL(api.purchaseOrders.list.path, window.location.origin);
      if (filters?.vendorId) url.searchParams.set("vendorId", String(filters.vendorId));
      if (filters?.status) url.searchParams.set("status", filters.status);
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch purchase orders");
      return api.purchaseOrders.list.responses[200].parse(await res.json());
    },
  });
}

export function usePurchaseOrder(id: number) {
  return useQuery({
    queryKey: [api.purchaseOrders.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.purchaseOrders.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch purchase order");
      return api.purchaseOrders.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePurchaseOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertPurchaseOrder) => {
      // Ensure numeric fields are numbers
      const payload = {
        ...data,
        vendorId: Number(data.vendorId),
        items: data.items.map(item => ({
          ...item,
          quantity: Number(item.quantity),
          unitPrice: Number(item.unitPrice)
        }))
      };

      const res = await fetch(api.purchaseOrders.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create purchase order");
      return api.purchaseOrders.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.purchaseOrders.list.path] });
    },
  });
}

export function useUpdatePOStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: "draft" | "approved" | "partially_paid" | "fully_paid" }) => {
      const url = buildUrl(api.purchaseOrders.updateStatus.path, { id });
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update status");
      return api.purchaseOrders.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: [api.purchaseOrders.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.purchaseOrders.get.path, id] });
    },
  });
}
