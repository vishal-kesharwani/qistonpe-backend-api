import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useVendorOutstanding() {
  return useQuery({
    queryKey: [api.analytics.outstanding.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.outstanding.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch vendor outstanding analytics");
      return api.analytics.outstanding.responses[200].parse(await res.json());
    },
  });
}

export function usePaymentAging() {
  return useQuery({
    queryKey: [api.analytics.aging.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.aging.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch payment aging analytics");
      return api.analytics.aging.responses[200].parse(await res.json());
    },
  });
}
