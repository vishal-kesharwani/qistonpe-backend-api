import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertPayment } from "@shared/routes";

export function usePayments() {
  return useQuery({
    queryKey: [api.payments.list.path],
    queryFn: async () => {
      const res = await fetch(api.payments.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch payments");
      return api.payments.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertPayment) => {
      const payload = {
        ...data,
        purchaseOrderId: Number(data.purchaseOrderId),
        amount: Number(data.amount)
      };

      const res = await fetch(api.payments.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 409) throw new Error("Payment exceeds outstanding amount");
        throw new Error("Failed to record payment");
      }
      return api.payments.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
      // Invalidate POs because their status might change
      queryClient.invalidateQueries({ queryKey: [api.purchaseOrders.list.path] }); 
    },
  });
}
