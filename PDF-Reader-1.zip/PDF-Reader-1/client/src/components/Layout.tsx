import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  ShoppingCart, 
  CreditCard, 
  Menu,
  X,
  Package2
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/vendors", label: "Vendors", icon: Users },
    { href: "/purchase-orders", label: "Purchase Orders", icon: ShoppingCart },
    { href: "/payments", label: "Payments", icon: CreditCard },
  ];

  const NavContent = () => (
    <div className="space-y-6 py-6 h-full flex flex-col">
      <div className="px-6 flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg">
          <Package2 className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl tracking-tight">ProProcure</h2>
          <p className="text-xs text-muted-foreground">Manage with ease</p>
        </div>
      </div>
      
      <div className="px-4 space-y-1 flex-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                  isActive
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                onClick={() => setIsMobileOpen(false)}
              >
                <item.icon className={`h-5 w-5 ${isActive ? "text-primary-foreground" : "text-muted-foreground/70"}`} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="px-6 pb-2">
        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-4 text-white shadow-lg">
          <p className="font-display font-bold text-sm mb-1">Need Help?</p>
          <p className="text-xs text-white/80 mb-3">Check our documentation for advanced features.</p>
          <Button size="sm" variant="secondary" className="w-full text-xs h-8 bg-white/20 hover:bg-white/30 border-none text-white">
            View Docs
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 border-r border-border bg-card/50 backdrop-blur-xl fixed inset-y-0 z-30">
        <NavContent />
      </aside>

      {/* Mobile Sidebar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 border-b border-border bg-background/80 backdrop-blur-md z-40 flex items-center px-4 justify-between">
        <div className="flex items-center gap-2">
          <Package2 className="h-6 w-6 text-primary" />
          <span className="font-display font-bold text-lg">ProProcure</span>
        </div>
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72">
            <NavContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 pt-16 lg:pt-0 min-h-screen overflow-x-hidden">
        <div className="container max-w-7xl mx-auto p-4 md:p-8 animate-in fade-in duration-500 slide-in-from-bottom-4">
          {children}
        </div>
      </main>
    </div>
  );
}
