import { Badge } from "@/components/ui/badge";

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const getStyles = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
      case "fully_paid":
      case "approved":
        return "bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border-emerald-200";
      case "inactive":
      case "draft":
        return "bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200";
      case "partially_paid":
        return "bg-amber-100 text-amber-800 hover:bg-amber-200 border-amber-200";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getLabel = (status: string) => {
    return status.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <Badge variant="outline" className={`${getStyles(status)} px-3 py-0.5 rounded-full font-medium transition-colors`}>
      {getLabel(status)}
    </Badge>
  );
}
