import { usePayments, useCreatePayment } from "@/hooks/use-payments";
import { usePurchaseOrders } from "@/hooks/use-purchase-orders";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, CreditCard, ExternalLink } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPaymentSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import type { InsertPayment } from "@shared/routes";
import { Textarea } from "@/components/ui/textarea";

export default function Payments() {
  const { data: payments, isLoading } = usePayments();
  const [search, setSearch] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const filteredPayments = payments?.filter(p => 
    p.paymentRef.toLowerCase().includes(search.toLowerCase()) || 
    p.purchaseOrder.poNumber.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Payments</h1>
          <p className="text-muted-foreground mt-1">Track outgoing payments</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search payments..." 
              className="pl-9 bg-card"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20">
                <CreditCard className="h-4 w-4 mr-2" /> Record Payment
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Record Payment</DialogTitle>
                <DialogDescription>Link a payment to a Purchase Order.</DialogDescription>
              </DialogHeader>
              <PaymentForm onSuccess={() => setIsCreateOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50 hover:bg-muted/50">
              <TableHead>Payment Ref</TableHead>
              <TableHead>PO Number</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Method</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead className="text-right">Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">Loading payments...</TableCell>
              </TableRow>
            ) : filteredPayments?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">No payments found</TableCell>
              </TableRow>
            ) : (
              filteredPayments?.map((payment) => (
                <TableRow key={payment.id} className="hover:bg-muted/30 transition-colors">
                  <TableCell className="font-mono font-medium">{payment.paymentRef}</TableCell>
                  <TableCell className="flex items-center gap-2">
                    {payment.purchaseOrder.poNumber}
                    <ExternalLink className="h-3 w-3 text-muted-foreground" />
                  </TableCell>
                  <TableCell>{format(new Date(payment.date), 'MMM dd, yyyy')}</TableCell>
                  <TableCell className="capitalize">{payment.method}</TableCell>
                  <TableCell className="font-bold text-emerald-600">
                    -${Number(payment.amount).toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right text-muted-foreground max-w-[200px] truncate">
                    {payment.notes}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function PaymentForm({ onSuccess }: { onSuccess: () => void }) {
  const { toast } = useToast();
  // Fetch POs that are NOT fully paid
  const { data: pos } = usePurchaseOrders();
  const payablePos = pos?.filter(po => po.status !== 'fully_paid');
  
  const createMutation = useCreatePayment();

  const form = useForm<InsertPayment>({
    resolver: zodResolver(insertPaymentSchema),
    defaultValues: {
      method: "neft",
      notes: ""
    }
  });

  // Watch PO ID to set max amount
  const selectedPoId = form.watch("purchaseOrderId");
  const selectedPo = payablePos?.find(po => po.id === Number(selectedPoId));

  const onSubmit = (data: InsertPayment) => {
    createMutation.mutate(data, {
      onSuccess: () => {
        toast({ title: "Success", description: "Payment recorded successfully" });
        onSuccess();
      },
      onError: (err) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="purchaseOrderId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Purchase Order</FormLabel>
              <Select onValueChange={(v) => field.onChange(parseInt(v))}>
                <FormControl>
                  <SelectTrigger><SelectValue placeholder="Select PO to pay" /></SelectTrigger>
                </FormControl>
                <SelectContent>
                  {payablePos?.map(po => (
                    <SelectItem key={po.id} value={String(po.id)}>
                      {po.poNumber} - {po.vendor.name} (${Number(po.totalAmount).toLocaleString()})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="amount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Amount</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={e => field.onChange(parseFloat(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
                {selectedPo && (
                  <p className="text-xs text-muted-foreground">
                    Total: ${Number(selectedPo.totalAmount).toLocaleString()}
                  </p>
                )}
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="method"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Payment Method</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="neft">NEFT</SelectItem>
                    <SelectItem value="rtgs">RTGS</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                    <SelectItem value="cash">Cash</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes (Optional)</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Transaction ref, remarks..." />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="outline" onClick={onSuccess}>Cancel</Button>
          <Button type="submit" disabled={createMutation.isPending}>
            {createMutation.isPending ? "Recording..." : "Record Payment"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
