import { pgTable, text, serial, integer, numeric, timestamp, date, jsonb, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  contactPerson: text("contact_person").notNull(),
  email: text("email").notNull(), // Unique check handled in logic or DB constraint
  phone: text("phone").notNull(),
  paymentTerms: integer("payment_terms").notNull(), // 7, 15, 30, 45, 60
  status: text("status", { enum: ["active", "inactive"] }).notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const purchaseOrders = pgTable("purchase_orders", {
  id: serial("id").primaryKey(),
  poNumber: text("po_number").notNull().unique(),
  vendorId: integer("vendor_id").notNull(), // Foreign key reference defined in relations
  date: timestamp("date").notNull().defaultNow(),
  dueDate: timestamp("due_date").notNull(),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status", { enum: ["draft", "approved", "partially_paid", "fully_paid"] }).notNull().default("draft"),
  items: jsonb("items").$type<{ description: string; quantity: number; unitPrice: number }[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  paymentRef: text("payment_ref").notNull().unique(),
  purchaseOrderId: integer("purchase_order_id").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  method: text("method", { enum: ["cash", "cheque", "neft", "rtgs", "upi"] }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const vendorsRelations = relations(vendors, ({ many }) => ({
  purchaseOrders: many(purchaseOrders),
}));

export const purchaseOrdersRelations = relations(purchaseOrders, ({ one, many }) => ({
  vendor: one(vendors, {
    fields: [purchaseOrders.vendorId],
    references: [vendors.id],
  }),
  payments: many(payments),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  purchaseOrder: one(purchaseOrders, {
    fields: [payments.purchaseOrderId],
    references: [purchaseOrders.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertVendorSchema = createInsertSchema(vendors).omit({ id: true, createdAt: true });
export const insertPurchaseOrderSchema = createInsertSchema(purchaseOrders).omit({ 
  id: true, 
  createdAt: true,
  poNumber: true, // Auto-generated
  dueDate: true,  // Auto-calculated
  totalAmount: true, // Auto-calculated
  status: true // Default to draft/approved
}).extend({
  items: z.array(z.object({
    description: z.string(),
    quantity: z.number().positive(),
    unitPrice: z.number().positive()
  })).min(1)
});

export const insertPaymentSchema = createInsertSchema(payments).omit({ 
  id: true, 
  createdAt: true,
  paymentRef: true // Auto-generated
});

// === EXPLICIT API CONTRACT TYPES ===

export type Vendor = typeof vendors.$inferSelect;
export type InsertVendor = z.infer<typeof insertVendorSchema>;

export type PurchaseOrder = typeof purchaseOrders.$inferSelect;
// We need a specific type that includes relations for the UI
export type PurchaseOrderWithDetails = PurchaseOrder & { vendor: Vendor; payments: Payment[] };

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

// Analytics Types
export type VendorOutstanding = {
  vendorId: number;
  vendorName: string;
  totalOrders: number;
  totalPaid: number;
  outstandingAmount: number;
};

export type PaymentAging = {
  range: "0-30" | "31-60" | "61-90" | "90+";
  amount: number;
  count: number;
};
