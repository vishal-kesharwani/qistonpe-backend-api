import { z } from 'zod';
import { 
  insertVendorSchema, 
  insertPurchaseOrderSchema, 
  insertPaymentSchema,
  vendors, 
  purchaseOrders, 
  payments 
} from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  conflict: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  vendors: {
    list: {
      method: 'GET' as const,
      path: '/api/vendors',
      responses: {
        200: z.array(z.custom<typeof vendors.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/vendors/:id',
      responses: {
        200: z.custom<typeof vendors.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/vendors',
      input: insertVendorSchema,
      responses: {
        201: z.custom<typeof vendors.$inferSelect>(),
        400: errorSchemas.validation,
        409: errorSchemas.conflict,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/vendors/:id',
      input: insertVendorSchema.partial(),
      responses: {
        200: z.custom<typeof vendors.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  purchaseOrders: {
    list: {
      method: 'GET' as const,
      path: '/api/purchase-orders',
      input: z.object({
        vendorId: z.coerce.number().optional(),
        status: z.enum(["draft", "approved", "partially_paid", "fully_paid"]).optional()
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof purchaseOrders.$inferSelect & { vendor: typeof vendors.$inferSelect }>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/purchase-orders/:id',
      responses: {
        200: z.custom<typeof purchaseOrders.$inferSelect & { vendor: typeof vendors.$inferSelect; payments: typeof payments.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/purchase-orders',
      input: insertPurchaseOrderSchema,
      responses: {
        201: z.custom<typeof purchaseOrders.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/purchase-orders/:id/status',
      input: z.object({ status: z.enum(["draft", "approved", "partially_paid", "fully_paid"]) }),
      responses: {
        200: z.custom<typeof purchaseOrders.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  payments: {
    list: {
      method: 'GET' as const,
      path: '/api/payments',
      responses: {
        200: z.array(z.custom<typeof payments.$inferSelect & { purchaseOrder: typeof purchaseOrders.$inferSelect }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/payments',
      input: insertPaymentSchema,
      responses: {
        201: z.custom<typeof payments.$inferSelect>(),
        400: errorSchemas.validation,
        409: errorSchemas.conflict, // Payment exceeds amount
      },
    },
  },
  analytics: {
    outstanding: {
      method: 'GET' as const,
      path: '/api/analytics/vendor-outstanding',
      responses: {
        200: z.array(z.object({
          vendorId: z.number(),
          vendorName: z.string(),
          totalOrders: z.number(),
          totalPaid: z.number(),
          outstandingAmount: z.number(),
        })),
      },
    },
    aging: {
      method: 'GET' as const,
      path: '/api/analytics/payment-aging',
      responses: {
        200: z.array(z.object({
          range: z.enum(["0-30", "31-60", "61-90", "90+"]),
          amount: z.number(),
          count: z.number(),
        })),
      },
    },
  },
};

// ============================================
// HELPER FUNCTION
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
