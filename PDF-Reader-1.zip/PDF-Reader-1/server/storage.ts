import { db } from "./db";
import {
  vendors, purchaseOrders, payments,
  type Vendor, type InsertVendor,
  type PurchaseOrder, type InsertPurchaseOrder, type PurchaseOrderWithDetails,
  type Payment, type InsertPayment,
  type VendorOutstanding, type PaymentAging
} from "@shared/schema";
import { eq, sql, desc } from "drizzle-orm";

export interface IStorage {
  // Vendors
  getVendors(): Promise<Vendor[]>;
  getVendor(id: number): Promise<Vendor | undefined>;
  getVendorByEmail(email: string): Promise<Vendor | undefined>;
  getVendorByName(name: string): Promise<Vendor | undefined>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  updateVendor(id: number, vendor: Partial<InsertVendor>): Promise<Vendor>;

  // Purchase Orders
  getPurchaseOrders(filter?: { vendorId?: number; status?: string }): Promise<PurchaseOrderWithDetails[]>;
  getPurchaseOrder(id: number): Promise<PurchaseOrderWithDetails | undefined>;
  createPurchaseOrder(po: InsertPurchaseOrder & { 
    poNumber: string, 
    dueDate: Date, 
    totalAmount: string 
  }): Promise<PurchaseOrder>;
  updatePurchaseOrderStatus(id: number, status: string): Promise<PurchaseOrder>;

  // Payments
  getPayments(): Promise<(Payment & { purchaseOrder: PurchaseOrder })[]>;
  createPayment(payment: InsertPayment & { paymentRef: string }): Promise<Payment>;

  // Analytics
  getVendorOutstanding(): Promise<VendorOutstanding[]>;
  getPaymentAging(): Promise<PaymentAging[]>;
}

export class DatabaseStorage implements IStorage {
  // Vendors
  async getVendors(): Promise<Vendor[]> {
    return await db.select().from(vendors).orderBy(desc(vendors.createdAt));
  }

  async getVendor(id: number): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.id, id));
    return vendor;
  }

  async getVendorByEmail(email: string): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.email, email));
    return vendor;
  }

  async getVendorByName(name: string): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.name, name));
    return vendor;
  }

  async createVendor(vendor: InsertVendor): Promise<Vendor> {
    const [newVendor] = await db.insert(vendors).values(vendor).returning();
    return newVendor;
  }

  async updateVendor(id: number, updates: Partial<InsertVendor>): Promise<Vendor> {
    const [updatedVendor] = await db.update(vendors)
      .set(updates)
      .where(eq(vendors.id, id))
      .returning();
    return updatedVendor;
  }

  // Purchase Orders
  async getPurchaseOrders(filter?: { vendorId?: number; status?: string }): Promise<PurchaseOrderWithDetails[]> {
    const query = db.query.purchaseOrders.findMany({
      with: {
        vendor: true,
        payments: true
      },
      orderBy: desc(purchaseOrders.createdAt)
    });
    
    // Note: Filtering would typically be done by adding .where() clauses
    // but Drizzle query builder syntax is cleaner this way for now.
    // In a real app we'd construct the where clause dynamically.
    const allOrders = await query;
    
    return allOrders.filter(order => {
      if (filter?.vendorId && order.vendorId !== filter.vendorId) return false;
      if (filter?.status && order.status !== filter.status) return false;
      return true;
    });
  }

  async getPurchaseOrder(id: number): Promise<PurchaseOrderWithDetails | undefined> {
    return await db.query.purchaseOrders.findFirst({
      where: eq(purchaseOrders.id, id),
      with: {
        vendor: true,
        payments: true
      }
    });
  }

  async createPurchaseOrder(po: InsertPurchaseOrder & { 
    poNumber: string, 
    dueDate: Date, 
    totalAmount: string 
  }): Promise<PurchaseOrder> {
    const [newPo] = await db.insert(purchaseOrders).values(po).returning();
    return newPo;
  }

  async updatePurchaseOrderStatus(id: number, status: string): Promise<PurchaseOrder> {
    // Valid status cast
    const validStatus = status as "draft" | "approved" | "partially_paid" | "fully_paid";
    const [updatedPo] = await db.update(purchaseOrders)
      .set({ status: validStatus })
      .where(eq(purchaseOrders.id, id))
      .returning();
    return updatedPo;
  }

  // Payments
  async getPayments(): Promise<(Payment & { purchaseOrder: PurchaseOrder })[]> {
    return await db.query.payments.findMany({
      with: {
        purchaseOrder: true
      },
      orderBy: desc(payments.createdAt)
    });
  }

  async createPayment(payment: InsertPayment & { paymentRef: string }): Promise<Payment> {
    // Transactional logic is handled in the route handler or service layer
    // but strictly speaking, insertion happens here.
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  // Analytics
  async getVendorOutstanding(): Promise<VendorOutstanding[]> {
    // In a real optimized query this would be raw SQL or a complex aggregate
    // For simplicity/lite mode, we'll fetch and calculate
    const allPOs = await this.getPurchaseOrders();
    
    const map = new Map<number, VendorOutstanding>();

    for (const po of allPOs) {
      if (!map.has(po.vendorId)) {
        map.set(po.vendorId, {
          vendorId: po.vendorId,
          vendorName: po.vendor.name,
          totalOrders: 0,
          totalPaid: 0,
          outstandingAmount: 0
        });
      }

      const entry = map.get(po.vendorId)!;
      const poAmount = parseFloat(po.totalAmount);
      
      const paidAmount = po.payments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
      
      entry.totalOrders += poAmount;
      entry.totalPaid += paidAmount;
      entry.outstandingAmount += (poAmount - paidAmount);
    }

    return Array.from(map.values()).filter(v => v.outstandingAmount > 0);
  }

  async getPaymentAging(): Promise<PaymentAging[]> {
    // Calculate aging buckets for outstanding amounts
    const allPOs = await this.getPurchaseOrders();
    const now = new Date();
    
    const buckets = {
      "0-30": { amount: 0, count: 0 },
      "31-60": { amount: 0, count: 0 },
      "61-90": { amount: 0, count: 0 },
      "90+": { amount: 0, count: 0 }
    };

    for (const po of allPOs) {
      if (po.status === 'fully_paid') continue;

      const poAmount = parseFloat(po.totalAmount);
      const paidAmount = po.payments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
      const outstanding = poAmount - paidAmount;

      if (outstanding <= 0) continue;

      // Age is based on Due Date? Or PO Date? Requirement: "Payment Aging" usually refers to overdue.
      // "Group overdue amounts by age buckets". So we compare Due Date to Now.
      const diffTime = now.getTime() - new Date(po.dueDate).getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays <= 0) continue; // Not overdue yet

      if (diffDays <= 30) {
        buckets["0-30"].amount += outstanding;
        buckets["0-30"].count++;
      } else if (diffDays <= 60) {
        buckets["31-60"].amount += outstanding;
        buckets["31-60"].count++;
      } else if (diffDays <= 90) {
        buckets["61-90"].amount += outstanding;
        buckets["61-90"].count++;
      } else {
        buckets["90+"].amount += outstanding;
        buckets["90+"].count++;
      }
    }

    return Object.entries(buckets).map(([range, data]) => ({
      range: range as any,
      amount: data.amount,
      count: data.count
    }));
  }
}

export const storage = new DatabaseStorage();
