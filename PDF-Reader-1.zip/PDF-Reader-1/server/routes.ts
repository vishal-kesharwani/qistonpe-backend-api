import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { format, addDays } from "date-fns";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === Vendors ===
  
  app.get(api.vendors.list.path, async (req, res) => {
    const vendors = await storage.getVendors();
    res.json(vendors);
  });

  app.get(api.vendors.get.path, async (req, res) => {
    const vendor = await storage.getVendor(Number(req.params.id));
    if (!vendor) {
      return res.status(404).json({ message: 'Vendor not found' });
    }
    res.json(vendor);
  });

  app.post(api.vendors.create.path, async (req, res) => {
    try {
      const input = api.vendors.create.input.parse(req.body);
      
      // Unique name check
      const existing = await storage.getVendorByName(input.name);
      if (existing) {
        return res.status(409).json({ message: 'Vendor name already exists' });
      }

      const vendor = await storage.createVendor(input);
      res.status(201).json(vendor);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.vendors.update.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const existing = await storage.getVendor(id);
      if (!existing) return res.status(404).json({ message: 'Vendor not found' });

      const input = api.vendors.update.input.parse(req.body);
      const updated = await storage.updateVendor(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // === Purchase Orders ===

  app.get(api.purchaseOrders.list.path, async (req, res) => {
    const filters = {
      vendorId: req.query.vendorId ? Number(req.query.vendorId) : undefined,
      status: req.query.status as string | undefined
    };
    const orders = await storage.getPurchaseOrders(filters);
    res.json(orders);
  });

  app.get(api.purchaseOrders.get.path, async (req, res) => {
    const order = await storage.getPurchaseOrder(Number(req.params.id));
    if (!order) return res.status(404).json({ message: 'PO not found' });
    res.json(order);
  });

  app.post(api.purchaseOrders.create.path, async (req, res) => {
    try {
      const input = api.purchaseOrders.create.input.parse(req.body);
      
      const vendor = await storage.getVendor(input.vendorId);
      if (!vendor) return res.status(404).json({ message: 'Vendor not found' });
      if (vendor.status !== 'active') return res.status(400).json({ message: 'Cannot create PO for inactive vendor' });

      // Auto-calculations
      const date = new Date();
      const dueDate = addDays(date, vendor.paymentTerms);
      const poNumber = `PO-${format(date, 'yyyyMMdd')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
      
      const totalAmount = input.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0).toString();

      const po = await storage.createPurchaseOrder({
        ...input,
        poNumber,
        dueDate,
        totalAmount
      });

      res.status(201).json(po);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.patch(api.purchaseOrders.updateStatus.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { status } = api.purchaseOrders.updateStatus.input.parse(req.body);
      
      const po = await storage.getPurchaseOrder(id);
      if (!po) return res.status(404).json({ message: 'PO not found' });

      const updated = await storage.updatePurchaseOrderStatus(id, status);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message
        });
      }
      throw err;
    }
  });

  // === Payments ===

  app.get(api.payments.list.path, async (req, res) => {
    const payments = await storage.getPayments();
    res.json(payments);
  });

  app.post(api.payments.create.path, async (req, res) => {
    try {
      const input = api.payments.create.input.parse(req.body);
      
      const po = await storage.getPurchaseOrder(input.purchaseOrderId);
      if (!po) return res.status(404).json({ message: 'PO not found' });

      // Calculate outstanding
      const paidAmount = po.payments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
      const totalAmount = parseFloat(po.totalAmount);
      const currentOutstanding = totalAmount - paidAmount;
      const newPaymentAmount = input.amount; // already number from Zod coercion/check? No, schema has it as number/string?
      // Wait, schema defined amount as number in Zod but numeric in DB.
      // We should ensure input.amount is treated as number for calculation
      
      if (newPaymentAmount > currentOutstanding) {
        return res.status(409).json({ 
          message: `Payment amount (${newPaymentAmount}) exceeds outstanding balance (${currentOutstanding})` 
        });
      }

      // Generate Ref
      const paymentRef = `PAY-${format(new Date(), 'yyyyMMdd')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;

      // Create Payment
      const payment = await storage.createPayment({
        ...input,
        paymentRef
      });

      // Update PO Status
      const newTotalPaid = paidAmount + newPaymentAmount;
      const newStatus = newTotalPaid >= totalAmount ? 'fully_paid' : 'partially_paid';
      
      if (po.status !== newStatus) {
        await storage.updatePurchaseOrderStatus(po.id, newStatus);
      }

      res.status(201).json(payment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message
        });
      }
      throw err;
    }
  });

  // === Analytics ===

  app.get(api.analytics.outstanding.path, async (req, res) => {
    const data = await storage.getVendorOutstanding();
    res.json(data);
  });

  app.get(api.analytics.aging.path, async (req, res) => {
    const data = await storage.getPaymentAging();
    res.json(data);
  });

  // === Seeding ===
  // Simple seed endpoint for dev
  app.post('/api/seed', async (req, res) => {
    const vendors = await storage.getVendors();
    if (vendors.length > 0) return res.json({ message: "Already seeded" });

    // Seed Vendors
    const v1 = await storage.createVendor({
      name: "Acme Supplies",
      contactPerson: "John Doe",
      email: "john@acme.com",
      phone: "555-0100",
      paymentTerms: 30,
      status: "active"
    });
    
    const v2 = await storage.createVendor({
      name: "Global Tech",
      contactPerson: "Jane Smith",
      email: "jane@global.com",
      phone: "555-0200",
      paymentTerms: 15,
      status: "active"
    });

    // Seed POs
    const po1 = await storage.createPurchaseOrder({
      vendorId: v1.id,
      items: [{ description: "Widgets", quantity: 100, unitPrice: 10 }],
      poNumber: "PO-SEED-001",
      dueDate: addDays(new Date(), 30),
      totalAmount: "1000.00"
    });
    await storage.updatePurchaseOrderStatus(po1.id, "approved");

    const po2 = await storage.createPurchaseOrder({
      vendorId: v2.id,
      items: [{ description: "Service Fee", quantity: 1, unitPrice: 500 }],
      poNumber: "PO-SEED-002",
      dueDate: addDays(new Date(), 15),
      totalAmount: "500.00"
    });
    await storage.updatePurchaseOrderStatus(po2.id, "partially_paid");

    // Seed Payment
    await storage.createPayment({
      purchaseOrderId: po2.id,
      amount: 250,
      method: "neft",
      notes: "Part payment",
      paymentRef: "PAY-SEED-001"
    });

    res.json({ message: "Seeded successfully" });
  });

  return httpServer;
}
